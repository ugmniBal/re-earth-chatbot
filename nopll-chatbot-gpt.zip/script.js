
async function getGptResponse(message) {
    const apiKey = "YOUR_OPENAI_API_KEY"; // 실제 키로 교체 필요
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
                { role: "system", content: "너는 분리배출 전문가야. 사용자의 질문에 친절하게 안내해줘." },
                { role: "user", content: message }
            ]
        })
    });
    const data = await response.json();
    return data.choices[0].message.content;
}

async function getBotResponse(message) {
    const response = await fetch('items.json');
    const items = await response.json();

    for (let item of items) {
        if (message.includes(item.itemName)) {
            return item.disposalGuide;
        }
    }

    return await getGptResponse(message);
}

document.getElementById("send-btn").addEventListener("click", async () => {
    const input = document.getElementById("user-input");
    const chatBox = document.getElementById("chat-box");
    const message = input.value;
    if (!message) return;

    const userMessage = `<div class="message user">👤 ${message}</div>`;
    chatBox.innerHTML += userMessage;
    input.value = "";

    const botReply = await getBotResponse(message);
    const botMessage = `<div class="message bot">🤖 ${botReply}</div>`;
    chatBox.innerHTML += botMessage;
    chatBox.scrollTop = chatBox.scrollHeight;
});
