
// Replace with your Firebase project config
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

function addItem() {
    const name = document.getElementById("item-name").value.trim();
    const guide = document.getElementById("disposal-guide").value.trim();
    if (!name || !guide) return alert("모든 항목을 입력해주세요.");

    db.ref('items/' + name).set({
        itemName: name,
        disposalGuide: guide
    }, () => {
        alert("저장되었습니다.");
        document.getElementById("result").textContent = name + " 저장 완료!";
    });
}
