
// Replace with your Firebase project config
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

async function getGptResponse(message) {
    const apiKey = "YOUR_OPENAI_API_KEY";
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
                { role: "system", content: "너는 분리배출 전문가야. 사용자 질문에 정확하게 응답해줘." },
                { role: "user", content: message }
            ]
        })
    });
    const data = await response.json();
    return data.choices[0].message.content;
}

function logMessage(userMsg) {
    const timestamp = new Date().toISOString();
    db.ref('logs/' + Date.now()).set({
        message: userMsg,
        time: timestamp
    });
}

async function getBotResponse(message) {
    return new Promise(resolve => {
        db.ref('items').once('value', async snapshot => {
            const items = snapshot.val() || {};
            for (let key in items) {
                if (message.includes(key)) {
                    logMessage(message);
                    return resolve(items[key].disposalGuide);
                }
            }
            const gptReply = await getGptResponse(message);
            logMessage(message);
            resolve(gptReply);
        });
    });
}

document.getElementById("send-btn").addEventListener("click", async () => {
    const input = document.getElementById("user-input");
    const chatBox = document.getElementById("chat-box");
    const message = input.value;
    if (!message) return;

    chatBox.innerHTML += `<div class="message user">👤 ${message}</div>`;
    input.value = "";

    const botReply = await getBotResponse(message);
    chatBox.innerHTML += `<div class="message bot">🤖 ${botReply}</div>`;
    chatBox.scrollTop = chatBox.scrollHeight;
});
